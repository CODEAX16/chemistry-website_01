# ChemLab roadmap
- [x] Update institution and credits throughout website, metadata, README and PDFs; audit removed text and logo images.
- [x] Design system, global molecule state, navbar/footer, Ctrl+K search
- [x] Home page (hero 3D caffeine, features, gallery, molecule of the day, timeline, credits)
- [x] Visualization Lab (2D, info card, σ/π, 3D viewer + controls, legend)
- [x] Properties report (metrics, gauges, Lipinski, table, CSV, PDF)
- [ ] Theory page (SMILES builder, descriptor cards, 3D style comparison, Lipinski)
- [ ] Structure–Property analysis (table, charts, insight, CSV)
- [ ] Assessment quiz (12 MCQs + structure challenges, confetti)
- [ ] Final project report form (combined PDF via src/lib/pdf.ts)
