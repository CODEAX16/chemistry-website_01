import { createFileRoute } from "@tanstack/react-router";
import { useRef, useState } from "react";
import { Copy, Download, RotateCcw, Info } from "lucide-react";
import { toast } from "sonner";
import { SmilesInput } from "@/components/chem/SmilesInput";
import { MolSvg } from "@/components/chem/MolSvg";
import { Viewer3D, STYLE_LABELS, type Style3D, type Viewer3DHandle } from "@/components/chem/Viewer3D";
import { AtomLegend } from "@/components/chem/AtomLegend";
import { PageHeader } from "@/components/chem/motion";
import { useMol } from "@/lib/molstate";
import { drawSvg, svgToPng } from "@/lib/rdkit";
import type { Source3D } from "@/lib/structure3d";
import { Button } from "@/components/ui/button";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { Skeleton } from "@/components/ui/skeleton";
import { ToggleGroup, ToggleGroupItem } from "@/components/ui/toggle-group";

export const Route = createFileRoute("/lab")({
  head: () => ({
    meta: [
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
      { title: "Molecular Visualization Lab — ChemLab · SRM Institute of Science and Technology, Tiruchirappalli" },
      { name: "description", content: "Enter a SMILES string to see its 2D structure, molecular information and interactive 3D model. SRM Institute of Science and Technology, Tiruchirappalli · Department of Computer Science and Engineering (Cyber Security) · Rebuilt and modified by K.Likith Sai Vishal and P. Samuel" },
      { property: "og:title", content: "Molecular Visualization Lab — ChemLab · SRM Institute of Science and Technology, Tiruchirappalli" },
      { property: "og:description", content: "2D structures, σ/π bond counts and an interactive 3D viewer for any SMILES. SRM Institute of Science and Technology, Tiruchirappalli · Department of Computer Science and Engineering (Cyber Security) · Rebuilt and modified by K.Likith Sai Vishal and P. Samuel" },
    ],
  }),
  component: Lab,
});

const BACKGROUNDS = [
  { v: "transparent", l: "Lab" },
  { v: "#ffffff", l: "White" },
  { v: "#000000", l: "Black" },
];

function dl(href: string, name: string) {
  const a = document.createElement("a");
  a.href = href;
  a.download = name;
  a.click();
}

function Lab() {
  const { info, smiles, name, ready } = useMol();
  const [style, setStyle] = useState<Style3D>("ballstick");
  const [surface, setSurface] = useState(false);
  const [spin, setSpin] = useState(true);
  const [labels, setLabels] = useState(false);
  const [bg, setBg] = useState(0);
  const [source, setSource] = useState<Source3D | null>(null);
  const viewer = useRef<Viewer3DHandle>(null);

  const fileBase = name.replace(/\s+/g, "_").toLowerCase();
  const downloadSvg = () => {
    const svg = drawSvg(smiles, 600, 450);
    if (svg) dl(URL.createObjectURL(new Blob([svg], { type: "image/svg+xml" })), `${fileBase}.svg`);
  };
  const downloadPng = async () => {
    const svg = drawSvg(smiles, 600, 450);
    if (svg) dl(await svgToPng(svg), `${fileBase}.png`);
  };

  const rows: [string, string | number, boolean?][] = info
    ? [
        ["Input SMILES", info.input, true],
        ["Canonical SMILES", info.canonical, true],
        ["Molecular formula", info.formula],
        ["Heavy atoms", info.heavyAtoms],
        ["Total atoms (incl. H)", info.totalAtoms],
        ["Heavy-atom bonds", info.heavyBonds],
        ["σ (sigma) bonds", info.sigma],
        ["π (pi) bonds", info.pi],
        ["Total bonds", info.totalBonds],
      ]
    : [];

  return (
    <div>
      <PageHeader eyebrow="Molecular Visualization Lab" title={<>See your molecule <span className="text-gradient">come alive</span></>} subtitle="Type a SMILES string — the selected molecule follows you across every page." />
      <SmilesInput />

      <div className="mt-6 grid gap-6 lg:grid-cols-2">
        <section className="glass rounded-2xl p-5" aria-labelledby="h2d">
          <div className="mb-4 flex items-center justify-between gap-2">
            <h2 id="h2d" className="text-lg font-semibold">2D Structure</h2>
            <div className="flex gap-2">
              <Button size="sm" variant="outline" onClick={downloadPng} disabled={!info} className="gap-1.5">
                <Download className="h-3.5 w-3.5" /> PNG
              </Button>
              <Button size="sm" variant="outline" onClick={downloadSvg} disabled={!info} className="gap-1.5">
                <Download className="h-3.5 w-3.5" /> SVG
              </Button>
            </div>
          </div>
          <MolSvg smiles={smiles} width={480} height={360} label={`2D structure of ${name}`} />
          <p className="mt-3 text-center font-display text-sm text-muted-foreground">{name}</p>
        </section>

        <section className="glass rounded-2xl p-5" aria-labelledby="hinfo">
          <h2 id="hinfo" className="mb-4 text-lg font-semibold">Molecular Information</h2>
          {!ready ? (
            <div className="space-y-3">{Array.from({ length: 9 }).map((_, i) => <Skeleton key={i} className="h-8 w-full" />)}</div>
          ) : !info ? (
            <p className="text-sm text-muted-foreground">Enter a valid SMILES to see information.</p>
          ) : (
            <dl className="divide-y divide-border">
              {rows.map(([k, v, mono]) => (
                <div key={k} className="flex items-center justify-between gap-4 py-2.5">
                  <dt className="text-sm text-muted-foreground">{k}</dt>
                  <dd className={mono ? "flex min-w-0 items-center gap-1 font-mono text-sm" : "font-display text-base font-semibold"}>
                    <span className="truncate">{v}</span>
                    {k === "Canonical SMILES" && (
                      <button
                        aria-label="Copy canonical SMILES"
                        className="rounded p-1 text-muted-foreground hover:text-cyan"
                        onClick={() => {
                          navigator.clipboard.writeText(String(v));
                          toast.success("Canonical SMILES copied");
                        }}
                      >
                        <Copy className="h-3.5 w-3.5" />
                      </button>
                    )}
                  </dd>
                </div>
              ))}
            </dl>
          )}
        </section>
      </div>

      <section className="glass mt-6 rounded-2xl p-5" aria-labelledby="h3d">
        <div className="mb-4 flex flex-wrap items-center justify-between gap-3">
          <h2 id="h3d" className="text-lg font-semibold">Interactive 3D Viewer</h2>
          <ToggleGroup type="single" value={style} onValueChange={(v) => v && setStyle(v as Style3D)} className="flex-wrap" aria-label="3D model style">
            {(Object.keys(STYLE_LABELS) as Style3D[]).map((s) => (
              <ToggleGroupItem key={s} value={s} className="px-3 text-xs data-[state=on]:bg-primary data-[state=on]:text-primary-foreground">
                {STYLE_LABELS[s]}
              </ToggleGroupItem>
            ))}
          </ToggleGroup>
        </div>
        <div className="flex flex-wrap items-center gap-x-6 gap-y-3 border-y border-border py-3 text-sm">
          {[
            ["vdW surface", surface, setSurface],
            ["Auto-rotate", spin, setSpin],
            ["Atom labels", labels, setLabels],
          ].map(([l, v, set]) => (
            <div key={l as string} className="flex items-center gap-2">
              <Switch id={l as string} checked={v as boolean} onCheckedChange={set as (b: boolean) => void} />
              <Label htmlFor={l as string}>{l as string}</Label>
            </div>
          ))}
          <Button size="sm" variant="outline" onClick={() => setBg((b) => (b + 1) % BACKGROUNDS.length)}>
            Background: {BACKGROUNDS[bg]!.l}
          </Button>
          <Button size="sm" variant="outline" className="gap-1.5" onClick={() => viewer.current?.reset()}>
            <RotateCcw className="h-3.5 w-3.5" /> Reset view
          </Button>
        </div>
        <div className="relative mt-4 h-[460px] overflow-hidden rounded-xl border border-border bg-background/40">
          <Viewer3D ref={viewer} smiles={smiles} style={style} surface={surface} spin={spin} labels={labels} background={BACKGROUNDS[bg]!.v} onSource={setSource} />
        </div>
        {source === "flat" && (
          <p className="mt-3 flex items-center gap-2 text-sm text-gold">
            <Info className="h-4 w-4" /> 3D coordinates were unavailable, so this view is built from the 2D layout (flat). Shapes are approximate.
          </p>
        )}
        {source && source !== "flat" && <p className="mt-3 text-xs text-muted-foreground">3D coordinates: PubChem conformer. Drag to rotate, scroll to zoom.</p>}
        <div className="mt-4">
          <AtomLegend />
        </div>
      </section>
    </div>
  );
}
