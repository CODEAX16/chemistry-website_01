import { createFileRoute, Link } from "@tanstack/react-router";
import { useState } from "react";
import { Atom, Droplets, FileDown, Hexagon, Loader2, Magnet, RotateCw, Scale, Sheet, Target, Waves, CheckCircle2, XCircle } from "lucide-react";
import { toast } from "sonner";
import { PageHeader, CountUp, Reveal } from "@/components/chem/motion";
import { SmilesInput } from "@/components/chem/SmilesInput";
import { MolSvg } from "@/components/chem/MolSvg";
import { Gauge } from "@/components/chem/Gauge";
import { useMol } from "@/lib/molstate";
import { downloadText, interpretLogP, interpretTPSA, lipinski, propertyRows, toCsv } from "@/lib/interpret";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/properties")({
  head: () => ({
    meta: [
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
      { title: "Molecular Properties Report — ChemLab · SRM Institute of Science and Technology, Tiruchirappalli" },
      { name: "description", content: "Descriptors with student-friendly interpretations, LogP/TPSA gauges, Lipinski Rule of Five, CSV and PDF export. SRM Institute of Science and Technology, Tiruchirappalli · Department of Computer Science and Engineering (Cyber Security) · Rebuilt and modified by K.Likith Sai Vishal and P. Samuel" },
      { property: "og:title", content: "Molecular Properties Report — ChemLab · SRM Institute of Science and Technology, Tiruchirappalli" },
      { property: "og:description", content: "Calculate and interpret MW, LogP, TPSA, H-bonding, rings and more. SRM Institute of Science and Technology, Tiruchirappalli · Department of Computer Science and Engineering (Cyber Security) · Rebuilt and modified by K.Likith Sai Vishal and P. Samuel" },
    ],
  }),
  component: Properties,
});

function Properties() {
  const { info, name, ready, smiles } = useMol();
  const [busy, setBusy] = useState(false);

  if (!ready || !info)
    return (
      <div>
        <PageHeader eyebrow="Properties Report" title="Molecular Properties" />
        <SmilesInput />
        <div className="mt-6 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          {Array.from({ length: 8 }).map((_, i) => <Skeleton key={i} className="h-28 rounded-2xl" />)}
        </div>
        {ready && <p className="mt-6 text-center text-muted-foreground">Enter a valid SMILES to generate the report.</p>}
      </div>
    );

  const metrics = [
    { icon: Scale, label: "Molecular Weight", v: info.mw, d: 2, unit: " g/mol" },
    { icon: Droplets, label: "LogP", v: info.logp, d: 2, unit: "" },
    { icon: Waves, label: "TPSA", v: info.tpsa, d: 2, unit: " Å²" },
    { icon: Hexagon, label: "Ring Count", v: info.rings, d: 0, unit: "" },
    { icon: Magnet, label: "H-bond Donors", v: info.hbd, d: 0, unit: "" },
    { icon: Target, label: "H-bond Acceptors", v: info.hba, d: 0, unit: "" },
    { icon: RotateCw, label: "Rotatable Bonds", v: info.rotb, d: 0, unit: "" },
    { icon: Atom, label: "Fraction Csp³", v: info.fsp3, d: 2, unit: "" },
  ];
  const rows = propertyRows(info);
  const lip = lipinski(info);

  const csv = () => {
    downloadText(`${name.replace(/\s+/g, "_")}_properties.csv`, toCsv([["Property", "Value", "Interpretation"], ["SMILES", info.input, ""], ...rows.map((r) => [r.label, r.value, r.interpretation])]));
  };
  const pdf = async () => {
    setBusy(true);
    try {
      const { generateReport } = await import("@/lib/pdf");
      const doc = await generateReport({ title: `Molecular Properties Report — ${name}`, molecules: [{ name, smiles }], includeAppendix: false });
      doc.save(`${name.replace(/\s+/g, "_")}_report.pdf`);
      toast.success("PDF report downloaded");
    } catch {
      toast.error("Could not create the PDF. Please try again.");
    } finally {
      setBusy(false);
    }
  };

  return (
    <div>
      <PageHeader eyebrow="Properties Report" title={<>Properties of <span className="text-gradient">{name}</span></>} subtitle="Computed descriptors with plain-language meaning." />
      <SmilesInput />

      <div className="mt-6 flex flex-wrap justify-end gap-2">
        <Button variant="outline" className="gap-2" onClick={csv}>
          <Sheet className="h-4 w-4" /> Download CSV
        </Button>
        <Button className="gap-2" onClick={pdf} disabled={busy}>
          {busy ? <Loader2 className="h-4 w-4 animate-spin" /> : <FileDown className="h-4 w-4" />} Download PDF report
        </Button>
      </div>

      <div className="mt-4 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        {metrics.map((m, i) => (
          <Reveal key={m.label} delay={i * 0.04}>
            <div className="glass group rounded-2xl p-5 transition-transform hover:-translate-y-1">
              <div className="flex items-center justify-between text-muted-foreground">
                <span className="text-xs font-semibold uppercase tracking-wider">{m.label}</span>
                <m.icon className="h-4 w-4 text-cyan" />
              </div>
              <div className="mt-3 font-display text-3xl font-bold">
                <CountUp value={m.v} decimals={m.d} />
                <span className="text-sm font-normal text-muted-foreground">{m.unit}</span>
              </div>
            </div>
          </Reveal>
        ))}
      </div>

      <div className="mt-6 grid gap-6 lg:grid-cols-3">
        <div className="glass rounded-2xl p-5 lg:col-span-1">
          <MolSvg smiles={smiles} width={360} height={270} />
          <p className="mt-3 font-mono text-xs text-muted-foreground break-all">{info.canonical}</p>
        </div>
        <div className="glass space-y-8 rounded-2xl p-6 lg:col-span-1">
          <div>
            <div className="mb-6 flex items-baseline justify-between">
              <h3 className="font-semibold">LogP — lipophilicity</h3>
              <span className="font-display text-xl font-bold">{info.logp.toFixed(2)}</span>
            </div>
            <Gauge value={info.logp} min={-3} max={7} zones={[
              { to: 0, label: "Hydrophilic", className: "bg-cyan/70" },
              { to: 1, label: "Low", className: "bg-success/70" },
              { to: 3, label: "Moderate", className: "bg-gold/70" },
              { to: 7, label: "High", className: "bg-destructive/70" },
            ]} />
            <p className="mt-3 text-sm text-muted-foreground">{interpretLogP(info.logp)}</p>
          </div>
          <div>
            <div className="mb-6 flex items-baseline justify-between">
              <h3 className="font-semibold">TPSA — polarity</h3>
              <span className="font-display text-xl font-bold">{info.tpsa.toFixed(1)} Å²</span>
            </div>
            <Gauge value={info.tpsa} min={0} max={200} zones={[
              { to: 60, label: "Low", className: "bg-success/70" },
              { to: 140, label: "Moderate", className: "bg-gold/70" },
              { to: 200, label: "High", className: "bg-destructive/70" },
            ]} />
            <p className="mt-3 text-sm text-muted-foreground">{interpretTPSA(info.tpsa)}</p>
          </div>
        </div>
        <div className="glass rounded-2xl p-6">
          <div className="flex items-center justify-between">
            <h3 className="font-semibold">Lipinski Rule of Five</h3>
            <span className={cn("rounded-full px-3 py-1 text-xs font-semibold", lip.druglike ? "bg-success/15 text-success" : "bg-destructive/15 text-destructive")}>
              {lip.druglike ? "Drug-like" : "Not drug-like"}
            </span>
          </div>
          <ul className="mt-5 space-y-3">
            {lip.rules.map((r) => (
              <li key={r.label} className="flex items-center justify-between rounded-xl border border-border bg-background/30 px-3 py-2.5">
                <div>
                  <p className="text-sm font-medium">{r.label}</p>
                  <p className="text-xs text-muted-foreground">Limit {r.limit}</p>
                </div>
                <div className="flex items-center gap-2">
                  <span className="font-display font-semibold">{Number.isInteger(r.value) ? r.value : r.value.toFixed(2)}</span>
                  {r.pass ? <CheckCircle2 className="h-5 w-5 text-success" aria-label="Pass" /> : <XCircle className="h-5 w-5 text-destructive" aria-label="Fail" />}
                </div>
              </li>
            ))}
          </ul>
          <p className="mt-4 text-xs text-muted-foreground">
            {lip.violations} violation{lip.violations === 1 ? "" : "s"} — up to one is allowed. <Link to="/theory" className="text-cyan hover:underline">Learn more</Link>
          </p>
        </div>
      </div>

      <div className="glass mt-6 overflow-hidden rounded-2xl">
        <div className="border-b border-border p-5">
          <h2 className="text-lg font-semibold">Full property table</h2>
        </div>
        <div className="overflow-x-auto">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead className="w-56">Property</TableHead>
                <TableHead className="w-32">Value</TableHead>
                <TableHead>Interpretation</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {rows.map((r) => (
                <TableRow key={r.key}>
                  <TableCell className="font-medium">{r.label}</TableCell>
                  <TableCell className="font-mono">{r.value}</TableCell>
                  <TableCell className="text-sm text-muted-foreground">{r.interpretation}</TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </div>
      </div>
    </div>
  );
}
