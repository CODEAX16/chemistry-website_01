import { createFileRoute, Link } from "@tanstack/react-router";
import { PageHeader } from "@/components/chem/motion";

export const Route = createFileRoute("/theory")({
  head: () => ({
    meta: [
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
      { title: "Theory — ChemLab · SRM Institute of Science and Technology, Tiruchirappalli" },
      { name: "description", content: "Theory section of the ChemLab cheminformatics virtual laboratory. SRM Institute of Science and Technology, Tiruchirappalli · Department of Computer Science and Engineering (Cyber Security) · Rebuilt and modified by K.Likith Sai Vishal and P. Samuel" },
      { property: "og:title", content: "Theory — ChemLab · SRM Institute of Science and Technology, Tiruchirappalli" },
      { property: "og:description", content: "Theory section of ChemLab. SRM Institute of Science and Technology, Tiruchirappalli · Department of Computer Science and Engineering (Cyber Security) · Rebuilt and modified by K.Likith Sai Vishal and P. Samuel" },
    ],
  }),
  component: Page,
});

function Page() {
  return (
    <div>
      <PageHeader eyebrow="Coming next" title="Theory" subtitle="This section is being built. Meanwhile, explore the Visualization Lab." />
      <div className="text-center"><Link to="/lab" className="text-cyan hover:underline">Open the lab →</Link></div>
    </div>
  );
}
