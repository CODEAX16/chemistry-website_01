import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { motion } from "framer-motion";
import { useState } from "react";
import {
  ArrowRight, BadgeCheck, Box, Calculator, FileText, GitCompare, GraduationCap, PenLine, Shapes, Sparkles, CalendarDays,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Viewer3D } from "@/components/chem/Viewer3D";
import { MolSvg } from "@/components/chem/MolSvg";
import { CountUp, Reveal } from "@/components/chem/motion";
import { CATEGORIES, EXAMPLES, moleculeOfTheDay, type Category } from "@/lib/molecules";
import { useMol } from "@/lib/molstate";
import { analyze } from "@/lib/rdkit";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
      { title: "ChemLab — Cheminformatics Virtual Laboratory · SRM Institute of Science and Technology, Tiruchirappalli" },
      { name: "description", content: "Explore molecules in 2D & 3D: validate SMILES, calculate descriptors, compare structures and take the quiz. SRM Institute of Science and Technology, Tiruchirappalli · Department of Computer Science and Engineering (Cyber Security) · Rebuilt and modified by K.Likith Sai Vishal and P. Samuel" },
      { property: "og:title", content: "ChemLab — Cheminformatics Virtual Laboratory · SRM Institute of Science and Technology, Tiruchirappalli" },
      { property: "og:description", content: "Explore molecules in 2D & 3D with SMILES, descriptors and interactive 3D models. SRM Institute of Science and Technology, Tiruchirappalli · Department of Computer Science and Engineering (Cyber Security) · Rebuilt and modified by K.Likith Sai Vishal and P. Samuel" },
    ],
  }),
  component: Home,
});

const FEATURES = [
  { icon: BadgeCheck, title: "Validate SMILES", text: "Live parsing with instant ✓ / ✗ feedback and canonical SMILES." },
  { icon: Shapes, title: "2D structures", text: "Crisp CPK-coloured skeletal drawings, downloadable as PNG or SVG." },
  { icon: Box, title: "Interactive 3D", text: "Rotate, zoom and switch between four model styles and surfaces." },
  { icon: Calculator, title: "Descriptors", text: "MW, LogP, TPSA, H-bonding, rings, Fsp³ with plain-language meaning." },
  { icon: GitCompare, title: "Compare molecules", text: "Side-by-side tables, bar, scatter and radar charts with insights." },
  { icon: GraduationCap, title: "Quiz", text: "Instant feedback, explanations and structure-recognition challenges." },
  { icon: FileText, title: "PDF reports", text: "Generate a formatted multi-molecule project report in one click." },
];

function Home() {
  const { setSmiles, info } = useMol();
  const navigate = useNavigate();
  const [cat, setCat] = useState<Category | "All">("All");
  const motd = moleculeOfTheDay();
  const open = (s: string) => {
    setSmiles(s);
    navigate({ to: "/lab" });
  };
  const list = EXAMPLES.filter((e) => cat === "All" || e.category === cat);

  return (
    <div className="space-y-28">
      {/* HERO */}
      <section className="grid items-center gap-10 pt-4 lg:grid-cols-[1.1fr_1fr]">
        <div>
          <motion.p initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} className="mb-5 inline-flex items-center gap-2 rounded-full border border-border bg-card px-3 py-1 text-xs font-medium text-muted-foreground">
            <Sparkles className="h-3.5 w-3.5 text-gold" /> Cheminformatics Virtual Laboratory · Department of Computer Science and Engineering (Cyber Security)
          </motion.p>
          <motion.h1 initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.05, duration: 0.7 }} className="text-5xl font-extrabold leading-[1.05] sm:text-6xl lg:text-7xl">
            Explore Molecules in <span className="text-gradient">2D &amp; 3D</span>
          </motion.h1>
          <motion.p initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.15 }} className="mt-6 max-w-xl text-lg text-muted-foreground">
            Convert SMILES into structures, spin molecules in three dimensions, calculate descriptors and discover how structure shapes properties — right in your browser.
          </motion.p>
          <motion.div initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.25 }} className="mt-8 flex flex-wrap gap-3">
            <Button asChild size="lg" className="h-12 gap-2 px-6 glow-cyan">
              <Link to="/lab">
                Start the Lab <ArrowRight className="h-4 w-4" />
              </Link>
            </Button>
            <Button asChild size="lg" variant="outline" className="h-12 bg-card/50 px-6">
              <Link to="/quiz">Take the Quiz</Link>
            </Button>
          </motion.div>
          <div className="mt-12 grid max-w-md grid-cols-3 gap-4">
            {[
              { v: 7, s: "", l: "Descriptors" },
              { v: 5, s: "", l: "3D styles" },
              { v: 14, s: "+", l: "Example molecules" },
            ].map((c) => (
              <div key={c.l}>
                <div className="font-display text-3xl font-bold text-foreground">
                  <CountUp value={c.v} suffix={c.s} />
                </div>
                <div className="text-xs uppercase tracking-wider text-muted-foreground">{c.l}</div>
              </div>
            ))}
          </div>
        </div>
        <motion.div initial={{ opacity: 0, scale: 0.94 }} animate={{ opacity: 1, scale: 1 }} transition={{ duration: 0.9 }} className="relative">
          <div className="absolute inset-8 rounded-full bg-cyan/20 blur-3xl" aria-hidden />
          <div className="glass gradient-border relative aspect-square overflow-hidden rounded-[2rem]">
            <Viewer3D smiles="CN1C=NC2=C1C(=O)N(C(=O)N2C)C" style="ballstick" spin interactive />
            <div className="pointer-events-none absolute bottom-4 left-4 rounded-xl border border-border bg-background/70 px-3 py-2 backdrop-blur">
              <p className="font-display text-sm font-semibold">Caffeine</p>
              <p className="font-mono text-xs text-muted-foreground">C₈H₁₀N₄O₂ · drag to rotate</p>
            </div>
          </div>
        </motion.div>
      </section>

      {/* FEATURES */}
      <section>
        <Reveal>
          <h2 className="text-center text-3xl font-bold sm:text-4xl">What can you do here?</h2>
          <p className="mx-auto mt-3 max-w-2xl text-center text-muted-foreground">Everything you need to represent and analyse chemical structures computationally.</p>
        </Reveal>
        <div className="mt-10 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          {FEATURES.map((f, i) => (
            <Reveal key={f.title} delay={i * 0.05}>
              <div className="glass group h-full rounded-2xl p-6 transition-all hover:-translate-y-1 hover:glow-cyan">
                <div className="mb-4 inline-flex h-11 w-11 items-center justify-center rounded-xl bg-primary/20 text-cyan transition-colors group-hover:bg-primary/40">
                  <f.icon className="h-5 w-5" />
                </div>
                <h3 className="font-semibold">{f.title}</h3>
                <p className="mt-1.5 text-sm text-muted-foreground">{f.text}</p>
              </div>
            </Reveal>
          ))}
          <Reveal delay={0.35}>
            <div className="h-full rounded-2xl border border-gold/40 bg-gold/10 p-6">
              <div className="mb-3 flex items-center gap-2 text-xs font-semibold uppercase tracking-wider text-gold">
                <CalendarDays className="h-4 w-4" /> Molecule of the Day
              </div>
              <MolSvg smiles={motd.smiles} width={260} height={150} />
              <h3 className="mt-3 font-semibold">{motd.name}</h3>
              <p className="mt-1 text-sm text-muted-foreground">{motd.fact}</p>
              <button onClick={() => open(motd.smiles)} className="mt-3 inline-flex items-center gap-1 text-sm font-medium text-gold hover:underline">
                Open in lab <ArrowRight className="h-3.5 w-3.5" />
              </button>
            </div>
          </Reveal>
        </div>
      </section>

      {/* GALLERY */}
      <section>
        <Reveal>
          <div className="flex flex-wrap items-end justify-between gap-4">
            <div>
              <h2 className="text-3xl font-bold sm:text-4xl">Example Molecule Gallery</h2>
              <p className="mt-2 text-muted-foreground">Click any card to load it into the lab.</p>
            </div>
            <div className="flex flex-wrap gap-2" role="group" aria-label="Filter by category">
              {(["All", ...CATEGORIES] as const).map((c) => (
                <button
                  key={c}
                  onClick={() => setCat(c)}
                  aria-pressed={cat === c}
                  className={cn(
                    "rounded-full border px-3.5 py-1.5 text-sm transition-colors",
                    cat === c ? "border-cyan bg-cyan/15 text-foreground" : "border-border text-muted-foreground hover:text-foreground",
                  )}
                >
                  {c}
                </button>
              ))}
            </div>
          </div>
        </Reveal>
        <div className="no-scrollbar -mx-4 mt-8 flex snap-x gap-4 overflow-x-auto px-4 pb-4">
          {list.map((e) => {
            const m = analyze(e.smiles);
            return (
              <motion.button
                layout
                key={e.smiles}
                onClick={() => open(e.smiles)}
                whileHover={{ y: -6 }}
                className={cn("glass w-64 shrink-0 snap-start rounded-2xl p-4 text-left", info?.input === e.smiles && "ring-2 ring-cyan")}
                aria-label={`Load ${e.name} into the lab`}
              >
                <MolSvg smiles={e.smiles} width={240} height={160} label={`2D structure of ${e.name}`} />
                <div className="mt-3 flex items-baseline justify-between gap-2">
                  <h3 className="font-semibold">{e.name}</h3>
                  <span className="text-[10px] uppercase tracking-wider text-gold">{e.category}</span>
                </div>
                <p className="mt-1 font-mono text-xs text-muted-foreground">
                  {m ? `${m.formula} · ${m.mw.toFixed(2)} g/mol` : "…"}
                </p>
                <p className="mt-2 line-clamp-2 text-xs text-muted-foreground">{e.fact}</p>
              </motion.button>
            );
          })}
        </div>
      </section>

      {/* HOW IT WORKS */}
      <section>
        <Reveal>
          <h2 className="text-center text-3xl font-bold sm:text-4xl">How it works</h2>
        </Reveal>
        <div className="relative mt-12 grid gap-6 md:grid-cols-3">
          <div className="absolute left-0 right-0 top-7 hidden h-px bg-gradient-to-r from-transparent via-cyan/50 to-transparent md:block" aria-hidden />
          {[
            { icon: PenLine, t: "Enter a SMILES", d: "Type a SMILES string or pick one of the example molecules." },
            { icon: Box, t: "Visualise", d: "See the 2D structure and explore an interactive 3D model." },
            { icon: Calculator, t: "Analyse & report", d: "Read descriptors, compare molecules and export a PDF report." },
          ].map((s, i) => (
            <Reveal key={s.t} delay={i * 0.1}>
              <div className="relative text-center">
                <div className="mx-auto flex h-14 w-14 items-center justify-center rounded-2xl border border-cyan/40 bg-background text-cyan glow-cyan">
                  <s.icon className="h-6 w-6" />
                </div>
                <p className="mt-4 text-xs font-semibold uppercase tracking-widest text-gold">Step {i + 1}</p>
                <h3 className="mt-1 text-lg font-semibold">{s.t}</h3>
                <p className="mx-auto mt-1 max-w-xs text-sm text-muted-foreground">{s.d}</p>
              </div>
            </Reveal>
          ))}
        </div>
      </section>

      {/* CREDIT / ABOUT */}
      <section id="about">
        <Reveal>
          <div className="glass gradient-border grid gap-6 rounded-3xl p-8 sm:p-10 md:grid-cols-[1fr_auto] md:items-center">
            <div>
              <p className="text-xs font-semibold uppercase tracking-widest text-cyan">About this laboratory</p>
              <h2 className="mt-2 text-2xl font-bold sm:text-3xl">SRM Institute of Science and Technology, Tiruchirappalli</h2>
              <p className="mt-2 text-muted-foreground">Department of Computer Science and Engineering (Cyber Security)</p>
              <p className="mt-4 max-w-2xl text-sm text-muted-foreground">
                Built for B.Tech and B.Sc students to represent, visualise and analyse chemical structures computationally — from SMILES to 3D models and structure–property relationships.
              </p>
            </div>
            <div className="rounded-2xl border border-gold/40 bg-gold/10 px-6 py-5">
              <p className="text-xs uppercase tracking-wider text-muted-foreground">REBUILT &amp; MODIFIED BY</p>
              <p className="font-display text-xl font-semibold text-gold">K. Likith Sai Vishal</p>
              <p className="font-display text-xl font-semibold text-gold">P. Samuel</p>
              <p className="text-sm text-muted-foreground">Department of Computer Science and Engineering (Cyber Security)</p>
            </div>
          </div>
        </Reveal>
      </section>
    </div>
  );
}
