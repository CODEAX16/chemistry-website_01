import type { MolInfo } from "./rdkit";

export const interpretLogP = (v: number) =>
  v < 0
    ? "Hydrophilic — prefers water over oil; likely quite water-soluble."
    : v < 1
      ? "Low lipophilicity — mostly water-friendly with slight oil affinity."
      : v <= 3
        ? "Moderate lipophilicity — a good balance between water and fat solubility."
        : "Strongly lipophilic — prefers fatty/oily environments; poor water solubility.";

export const interpretTPSA = (v: number) =>
  v < 60
    ? "Low polarity — few polar atoms; tends to cross cell membranes easily."
    : v <= 140
      ? "Moderate polarity — reasonable balance for oral absorption."
      : "High polarity — many polar groups; membrane permeability may be poor.";

export const interpretFsp3 = (v: number) =>
  v < 0.25
    ? "Planar/unsaturated — dominated by sp² carbons (aromatic or double bonds)."
    : v <= 0.6
      ? "Balanced — a mix of flat and three-dimensional carbon frameworks."
      : "Saturated/3D — mostly sp³ carbons, giving a more three-dimensional shape.";

export const interpretMW = (v: number) =>
  v < 160
    ? "Small molecule — light and usually volatile or highly mobile."
    : v <= 500
      ? "Medium size — typical of many drugs (within Lipinski's 500 Da limit)."
      : "Large molecule — exceeds 500 Da, which can reduce oral absorption.";

export const interpretHBD = (v: number) =>
  v === 0
    ? "No H-bond donors — cannot donate hydrogen bonds."
    : v <= 5
      ? `${v} donor${v > 1 ? "s" : ""} (OH/NH) — can donate hydrogen bonds; within Lipinski's limit.`
      : "Many donors — strong H-bonding; may limit membrane permeability.";

export const interpretHBA = (v: number) =>
  v === 0
    ? "No H-bond acceptors."
    : v <= 10
      ? `${v} acceptor${v > 1 ? "s" : ""} (O/N lone pairs) — can accept hydrogen bonds.`
      : "Many acceptors — very polar; exceeds Lipinski's limit of 10.";

export const interpretRotB = (v: number) =>
  v <= 3
    ? "Rigid — few freely rotating bonds."
    : v <= 10
      ? "Moderately flexible — several rotatable bonds allow different shapes."
      : "Highly flexible — many conformations possible; may reduce bioavailability.";

export const interpretRings = (v: number) =>
  v === 0 ? "Acyclic — an open-chain molecule with no rings." : v === 1 ? "One ring in the structure." : `${v} rings — a polycyclic framework.`;

export const interpretAromatic = (v: number) =>
  v === 0 ? "No aromatic rings — no delocalised π-electron ring system." : `${v} aromatic ring${v > 1 ? "s" : ""} — flat, stable, delocalised π system.`;

export const interpretMR = (v: number) =>
  v < 40
    ? "Low molar refractivity — small, weakly polarisable molecule."
    : v <= 130
      ? "Moderate molar refractivity — typical size/polarisability for drug-like molecules."
      : "High molar refractivity — large and highly polarisable.";

export interface PropertyRow {
  key: string;
  label: string;
  value: string;
  interpretation: string;
}

const f = (n: number, d = 2) => (Number.isInteger(n) ? String(n) : n.toFixed(d));

export function propertyRows(m: MolInfo): PropertyRow[] {
  return [
    { key: "formula", label: "Molecular formula", value: m.formula, interpretation: "Shows which elements are present and how many of each." },
    { key: "mw", label: "Molecular weight (g/mol)", value: f(m.mw), interpretation: interpretMW(m.mw) },
    { key: "exactMw", label: "Exact mass (Da)", value: m.exactMw.toFixed(4), interpretation: "Mass of the most abundant isotopes — used in mass spectrometry." },
    { key: "logp", label: "LogP (Crippen)", value: f(m.logp), interpretation: interpretLogP(m.logp) },
    { key: "tpsa", label: "TPSA (Å²)", value: f(m.tpsa), interpretation: interpretTPSA(m.tpsa) },
    { key: "hbd", label: "H-bond donors", value: f(m.hbd), interpretation: interpretHBD(m.hbd) },
    { key: "hba", label: "H-bond acceptors", value: f(m.hba), interpretation: interpretHBA(m.hba) },
    { key: "rotb", label: "Rotatable bonds", value: f(m.rotb), interpretation: interpretRotB(m.rotb) },
    { key: "rings", label: "Ring count", value: f(m.rings), interpretation: interpretRings(m.rings) },
    { key: "arom", label: "Aromatic rings", value: f(m.aromaticRings), interpretation: interpretAromatic(m.aromaticRings) },
    { key: "aliph", label: "Aliphatic rings", value: f(m.aliphaticRings), interpretation: m.aliphaticRings ? "Non-aromatic (saturated or partly saturated) rings present." : "No non-aromatic rings." },
    { key: "atoms", label: "Total atoms (incl. H)", value: f(m.totalAtoms), interpretation: `${m.heavyAtoms} heavy atoms + ${m.hydrogens} hydrogens.` },
    { key: "heavy", label: "Heavy atoms", value: f(m.heavyAtoms), interpretation: "Non-hydrogen atoms — a simple measure of molecular size." },
    { key: "hbonds", label: "Heavy-atom bonds", value: f(m.heavyBonds), interpretation: "Bonds between non-hydrogen atoms (the skeleton)." },
    { key: "sigma", label: "σ bonds", value: f(m.sigma), interpretation: "Every bond has exactly one σ bond — includes all C–H, O–H and N–H bonds." },
    { key: "pi", label: "π bonds", value: f(m.pi), interpretation: m.pi === 0 ? "Fully saturated — only single bonds." : "From double (1 π) and triple (2 π) bonds, aromatic rings counted in Kekulé form." },
    { key: "total", label: "Total bonds", value: f(m.totalBonds), interpretation: "Number of atom–atom connections including hydrogens (equal to σ count)." },
    { key: "fsp3", label: "Fraction Csp³", value: f(m.fsp3), interpretation: interpretFsp3(m.fsp3) },
    { key: "mr", label: "Molar refractivity", value: f(m.mr), interpretation: interpretMR(m.mr) },
  ];
}

export interface LipinskiRule {
  label: string;
  value: number;
  limit: string;
  pass: boolean;
}

export function lipinski(m: MolInfo) {
  const rules: LipinskiRule[] = [
    { label: "Molecular weight", value: m.mw, limit: "≤ 500", pass: m.mw <= 500 },
    { label: "LogP", value: m.logp, limit: "≤ 5", pass: m.logp <= 5 },
    { label: "H-bond donors", value: m.hbd, limit: "≤ 5", pass: m.hbd <= 5 },
    { label: "H-bond acceptors", value: m.hba, limit: "≤ 10", pass: m.hba <= 10 },
  ];
  const violations = rules.filter((r) => !r.pass).length;
  return { rules, violations, druglike: violations <= 1 };
}

export function keyPoints(name: string, m: MolInfo): [string, string][] {
  const l = lipinski(m);
  return [
    ["Molecular identity", `${name} has formula ${m.formula} and a molecular weight of ${m.mw.toFixed(2)} g/mol. ${interpretMW(m.mw)}`],
    ["Lipophilicity", `LogP = ${m.logp.toFixed(2)}. ${interpretLogP(m.logp)}`],
    ["Polarity", `TPSA = ${m.tpsa.toFixed(2)} Å². ${interpretTPSA(m.tpsa)}`],
    ["Hydrogen bonding", `${m.hbd} donor(s) and ${m.hba} acceptor(s). These control solubility and interactions with water and proteins.`],
    ["Flexibility", `${m.rotb} rotatable bond(s). ${interpretRotB(m.rotb)}`],
    ["Ring / aromatic character", `${m.rings} ring(s), of which ${m.aromaticRings} aromatic. ${interpretAromatic(m.aromaticRings)}`],
    ["σ / π bonding", `${m.sigma} σ bonds and ${m.pi} π bonds (total ${m.totalBonds} bonds).`],
    ["3D character", `Fsp³ = ${m.fsp3.toFixed(2)}. ${interpretFsp3(m.fsp3)}`],
    ["Overall conclusion", `${name} ${l.druglike ? "satisfies" : "does not satisfy"} Lipinski's Rule of Five (${l.violations} violation${l.violations === 1 ? "" : "s"}), suggesting it is ${l.druglike ? "likely" : "less likely"} to be orally bioavailable.`],
  ];
}

export function toCsv(rows: (string | number)[][]) {
  return rows.map((r) => r.map((c) => `"${String(c).replace(/"/g, '""')}"`).join(",")).join("\n");
}

export function downloadText(filename: string, text: string, type = "text/csv") {
  const url = URL.createObjectURL(new Blob([text], { type }));
  const a = document.createElement("a");
  a.href = url;
  a.download = filename;
  a.click();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
}
