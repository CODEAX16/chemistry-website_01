import bundled from "@/data/sdf3d.json";
import { flatMolblock } from "./rdkit";

export type Source3D = "pubchem" | "bundled" | "flat";
const memo = new Map<string, { data: string; source: Source3D }>();

/** 3D coordinates: PubChem → bundled example SDF → flat RDKit 2D layout. */
export async function get3D(smiles: string): Promise<{ data: string; source: Source3D } | null> {
  const key = smiles.trim();
  if (memo.has(key)) return memo.get(key)!;
  const local = (bundled as Record<string, string>)[key];
  if (local) {
    const r = { data: local, source: "bundled" as const };
    memo.set(key, r);
    return r;
  }
  try {
    const ctrl = new AbortController();
    const t = setTimeout(() => ctrl.abort(), 9000);
    const res = await fetch("https://pubchem.ncbi.nlm.nih.gov/rest/pug/compound/smiles/SDF?record_type=3d", {
      method: "POST",
      headers: { "Content-Type": "application/x-www-form-urlencoded" },
      body: "smiles=" + encodeURIComponent(key),
      signal: ctrl.signal,
    });
    clearTimeout(t);
    if (res.ok) {
      const txt = await res.text();
      if (txt.includes("M  END") || txt.includes("V2000")) {
        const r = { data: txt.split("$$$$")[0] ?? txt, source: "pubchem" as const };
        memo.set(key, r);
        return r;
      }
    }
  } catch {
    /* offline or not found */
  }
  const flat = flatMolblock(key);
  if (flat) {
    const r = { data: flat, source: "flat" as const };
    memo.set(key, r);
    return r;
  }
  return null;
}
