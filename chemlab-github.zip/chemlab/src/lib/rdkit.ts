/* RDKit.js (WASM) loader + molecule analysis. Browser-only: call from effects/handlers. */
/* eslint-disable @typescript-eslint/no-explicit-any */

let modulePromise: Promise<any> | null = null;
let RD: any = null;

export function loadRDKit(): Promise<any> {
  if (RD) return Promise.resolve(RD);
  if (modulePromise) return modulePromise;
  modulePromise = new Promise((resolve, reject) => {
    const init = () =>
      (window as any)
        .initRDKitModule({ locateFile: () => "/rdkit/RDKit_minimal.wasm" })
        .then((m: any) => {
          RD = m;
          resolve(m);
        })
        .catch(reject);
    if ((window as any).initRDKitModule) return init();
    const s = document.createElement("script");
    s.src = "/rdkit/RDKit_minimal.js";
    s.async = true;
    s.onload = init;
    s.onerror = () => reject(new Error("Could not load RDKit"));
    document.head.appendChild(s);
  });
  return modulePromise;
}

export function getRDKit() {
  return RD;
}

export interface MolInfo {
  input: string;
  canonical: string;
  formula: string;
  mw: number;
  exactMw: number;
  logp: number;
  mr: number;
  tpsa: number;
  hbd: number;
  hba: number;
  rotb: number;
  rings: number;
  aromaticRings: number;
  aliphaticRings: number;
  fsp3: number;
  heavyAtoms: number;
  totalAtoms: number;
  heavyBonds: number;
  sigma: number;
  pi: number;
  totalBonds: number;
  hydrogens: number;
}

const SYMBOLS: Record<number, string> = {
  1: "H", 3: "Li", 5: "B", 6: "C", 7: "N", 8: "O", 9: "F", 11: "Na", 12: "Mg", 14: "Si",
  15: "P", 16: "S", 17: "Cl", 19: "K", 20: "Ca", 26: "Fe", 29: "Cu", 30: "Zn", 34: "Se", 35: "Br", 53: "I",
};

function hillFormula(counts: Record<string, number>) {
  const keys = Object.keys(counts);
  const order: string[] = [];
  if (counts["C"]) {
    order.push("C");
    if (counts["H"]) order.push("H");
    keys.filter((k) => k !== "C" && k !== "H").sort().forEach((k) => order.push(k));
  } else keys.sort().forEach((k) => order.push(k));
  return order.map((k) => k + ((counts[k] ?? 0) > 1 ? counts[k] : "")).join("");
}

export function getMol(smiles: string): any | null {
  if (!RD || !smiles?.trim()) return null;
  try {
    const mol = RD.get_mol(smiles.trim());
    if (!mol) return null;
    if (!mol.is_valid()) {
      mol.delete();
      return null;
    }
    return mol;
  } catch {
    return null;
  }
}

export function isValidSmiles(smiles: string) {
  const m = getMol(smiles);
  if (!m) return false;
  m.delete();
  return true;
}

const cache = new Map<string, MolInfo | null>();

export function analyze(smiles: string): MolInfo | null {
  const key = smiles.trim();
  if (cache.has(key)) return cache.get(key)!;
  const mol = getMol(key);
  if (!mol) {
    if (RD) cache.set(key, null);
    return null;
  }
  try {
    const d = JSON.parse(mol.get_descriptors());
    const canonical = mol.get_smiles();
    // Kekulé form so aromatic bonds count as alternating single/double
    const kek = mol; // RDKit JSON output is already kekulized
    const json = JSON.parse(kek.get_json());
    const m0 = json.molecules[0];
    const atomDef = json.defaults?.atom ?? { z: 6, impHs: 0 };
    const bondDef = json.defaults?.bond ?? { bo: 1 };
    const counts: Record<string, number> = {};
    let hydrogens = 0;
    for (const a of m0.atoms ?? []) {
      const z = a.z ?? atomDef.z ?? 6;
      const sym = SYMBOLS[z] ?? `Z${z}`;
      counts[sym] = (counts[sym] ?? 0) + 1;
      const h = a.impHs ?? atomDef.impHs ?? 0;
      hydrogens += h;
    }
    const explicitH = counts["H"] ?? 0;
    if (hydrogens) counts["H"] = explicitH + hydrogens;
    let pi = 0;
    let aromaticBonds = 0;
    const bonds = m0.bonds ?? [];
    for (const b of bonds) {
      const bo = b.bo ?? bondDef.bo ?? 1;
      if (bo === 2) pi += 1;
      else if (bo === 3) pi += 2;
      else if (bo !== 1) aromaticBonds += 1;
    }
    pi += Math.floor(aromaticBonds / 2);
    if (kek !== mol) kek.delete();
    const heavyAtoms = (m0.atoms ?? []).length - explicitH;
    const heavyBonds = bonds.length;
    const sigma = heavyBonds + hydrogens;
    const info: MolInfo = {
      input: key,
      canonical,
      formula: hillFormula(counts),
      mw: d.amw,
      exactMw: d.exactmw,
      logp: d.CrippenClogP,
      mr: d.CrippenMR,
      tpsa: d.tpsa,
      hbd: d.NumHBD,
      hba: d.NumHBA,
      rotb: d.NumRotatableBonds,
      rings: d.NumRings,
      aromaticRings: d.NumAromaticRings,
      aliphaticRings: d.NumAliphaticRings,
      fsp3: d.FractionCSP3,
      heavyAtoms: d.NumHeavyAtoms ?? heavyAtoms,
      totalAtoms: (m0.atoms ?? []).length + hydrogens,
      heavyBonds,
      sigma,
      pi,
      totalBonds: sigma,
      hydrogens: counts["H"] ?? 0,
    };
    cache.set(key, info);
    return info;
  } catch {
    return null;
  } finally {
    mol.delete();
  }
}

export function drawSvg(smiles: string, width = 320, height = 240): string | null {
  const mol = getMol(smiles);
  if (!mol) return null;
  try {
    return mol.get_svg_with_highlights(
      JSON.stringify({ width, height, bondLineWidth: 1.6, clearBackground: false, addStereoAnnotation: false }),
    );
  } finally {
    mol.delete();
  }
}

/** 2D molblock with explicit hydrogens — used as a flat 3D-viewer fallback. */
export function flatMolblock(smiles: string): string | null {
  const mol = getMol(smiles);
  if (!mol) return null;
  try {
    const withH = RD.get_mol(mol.add_hs());
    withH.set_new_coords(true);
    const mb = withH.get_molblock();
    withH.delete();
    return mb;
  } catch {
    return null;
  } finally {
    mol.delete();
  }
}

export function svgToPng(svg: string, scale = 2): Promise<string> {
  return new Promise((resolve, reject) => {
    const img = new Image();
    const blob = new Blob([svg], { type: "image/svg+xml" });
    const url = URL.createObjectURL(blob);
    img.onload = () => {
      const c = document.createElement("canvas");
      c.width = img.width * scale;
      c.height = img.height * scale;
      const ctx = c.getContext("2d")!;
      ctx.fillStyle = "#ffffff";
      ctx.fillRect(0, 0, c.width, c.height);
      ctx.drawImage(img, 0, 0, c.width, c.height);
      URL.revokeObjectURL(url);
      resolve(c.toDataURL("image/png"));
    };
    img.onerror = reject;
    img.src = url;
  });
}
