import { createContext, useContext, useEffect, useMemo, useState, type ReactNode } from "react";
import { analyze, loadRDKit, type MolInfo } from "./rdkit";
import { DEFAULT_SMILES, findExample } from "./molecules";

interface MolState {
  ready: boolean;
  error: string | null;
  smiles: string;
  setSmiles: (s: string) => void;
  info: MolInfo | null;
  name: string;
}

const Ctx = createContext<MolState | null>(null);
const KEY = "chemlab.smiles";

export function MolProvider({ children }: { children: ReactNode }) {
  const [ready, setReady] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [smiles, setSmilesState] = useState(DEFAULT_SMILES);

  useEffect(() => {
    const saved = localStorage.getItem(KEY);
    if (saved) setSmilesState(saved);
    loadRDKit()
      .then(() => setReady(true))
      .catch((e) => setError(String(e?.message ?? e)));
  }, []);

  const setSmiles = (s: string) => {
    setSmilesState(s);
    try {
      localStorage.setItem(KEY, s);
    } catch {
      /* ignore */
    }
  };

  const info = useMemo(() => (ready ? analyze(smiles) : null), [ready, smiles]);
  const name = findExample(smiles)?.name ?? "Custom molecule";

  return <Ctx.Provider value={{ ready, error, smiles, setSmiles, info, name }}>{children}</Ctx.Provider>;
}

export function useMol() {
  const c = useContext(Ctx);
  if (!c) throw new Error("useMol must be used inside MolProvider");
  return c;
}
