/* eslint-disable @typescript-eslint/no-explicit-any */
import { analyze, drawSvg, svgToPng } from "./rdkit";
import { get3D } from "./structure3d";
import { keyPoints, lipinski, propertyRows } from "./interpret";

export interface ReportMolecule {
  name: string;
  smiles: string;
}
export interface ReportOptions {
  title: string;
  studentName?: string;
  regNo?: string;
  molecules: ReportMolecule[];
  includeAppendix?: boolean;
}

const INK: [number, number, number] = [10, 17, 40];
const ROYAL: [number, number, number] = [23, 71, 158];
const GOLD: [number, number, number] = [201, 162, 39];
const GREY: [number, number, number] = [95, 105, 125];

async function render3DPng(smiles: string): Promise<string | null> {
  const res = await get3D(smiles);
  if (!res) return null;
  const mod: any = await import("3dmol");
  const $3D = mod.default?.createViewer ? mod.default : mod;
  const host = document.createElement("div");
  host.style.cssText = "position:fixed;left:-10000px;top:0;width:480px;height:360px;";
  document.body.appendChild(host);
  try {
    const v = $3D.createViewer(host, { backgroundColor: "white", preserveDrawingBuffer: true });
    v.addModel(res.data, "sdf");
    v.setStyle({}, { stick: { radius: 0.14, colorscheme: "Jmol" }, sphere: { scale: 0.28, colorscheme: "Jmol" } });
    v.zoomTo();
    v.render();
    await new Promise((r) => setTimeout(r, 120));
    v.render();
    const uri = v.pngURI();
    v.clear();
    return uri;
  } catch {
    return null;
  } finally {
    host.remove();
  }
}

export async function generateReport(opts: ReportOptions, onProgress?: (msg: string) => void) {
  const { jsPDF } = await import("jspdf");
  const doc = new jsPDF({ unit: "mm", format: "a4" });
  const W = 210;
  const M = 16;
  let y = 0;
  const date = new Date().toLocaleDateString("en-IN", { day: "numeric", month: "long", year: "numeric" });

  const footer = () => {
    const n = doc.getNumberOfPages();
    for (let i = 1; i <= n; i++) {
      doc.setPage(i);
      doc.setDrawColor(...GOLD);
      doc.setLineWidth(0.3);
      doc.line(M, 284, W - M, 284);
      doc.setFontSize(6);
      doc.setTextColor(...GREY);
      doc.text("Cheminformatics Virtual Laboratory · SRM Institute of Science and Technology, Tiruchirappalli", M, 287);
      doc.text("Department of Computer Science and Engineering (Cyber Security)", M, 290);
      doc.text("Rebuilt and modified by K. Likith Sai Vishal and P. Samuel", M, 293);
      doc.text(`Page ${i} of ${n}`, W - M, 289, { align: "right" });
    }
  };
  const header = (title: string) => {
    doc.setFillColor(...INK);
    doc.rect(0, 0, W, 14, "F");
    doc.setFont("helvetica", "bold");
    doc.setFontSize(6);
    doc.setTextColor(255, 255, 255);
    doc.text("SRM Institute of Science and Technology, Tiruchirappalli", M, 4);
    doc.text("Department of Computer Science and Engineering (Cyber Security)", M, 8);
    doc.text("Rebuilt and modified by K. Likith Sai Vishal and P. Samuel", M, 12);
    doc.setFont("helvetica", "normal");
    doc.setFontSize(10);
    doc.setTextColor(180, 200, 230);
    doc.text(title, W - M, 9, { align: "right" });
    y = 24;
  };
  const newPage = (title: string) => {
    doc.addPage();
    header(title);
  };
  const ensure = (h: number, title: string) => {
    if (y + h > 278) newPage(title);
  };
  const h2 = (t: string) => {
    doc.setFont("helvetica", "bold");
    doc.setFontSize(13);
    doc.setTextColor(...ROYAL);
    doc.text(t, M, y);
    doc.setDrawColor(...GOLD);
    doc.setLineWidth(0.5);
    doc.line(M, y + 1.8, M + 24, y + 1.8);
    y += 8;
  };
  const para = (t: string, size = 9.5, color = INK, title = "") => {
    doc.setFont("helvetica", "normal");
    doc.setFontSize(size);
    doc.setTextColor(...color);
    const lines = doc.splitTextToSize(t, W - 2 * M);
    for (const l of lines) {
      ensure(5, title);
      doc.text(l, M, y);
      y += size * 0.45;
    }
  };

  // ---- Title page
  doc.setFillColor(...INK);
  doc.rect(0, 0, W, 297, "F");
  doc.setDrawColor(...GOLD);
  doc.setLineWidth(0.6);
  doc.line(M, 60, M + 40, 60);
  doc.setTextColor(255, 255, 255);
  doc.setFont("helvetica", "bold");
  doc.setFontSize(34);
  doc.text("ChemLab", M, 52);
  doc.setFontSize(18);
  doc.setFont("helvetica", "normal");
  doc.text(doc.splitTextToSize(opts.title, W - 2 * M), M, 76);
  doc.setFontSize(11);
  doc.setTextColor(127, 214, 240);
  doc.text("Cheminformatics Virtual Laboratory", M, 96);
  doc.setTextColor(200, 210, 230);
  doc.setFontSize(10);
  const inst = [
    "SRM Institute of Science and Technology, Tiruchirappalli",
    "Department of Computer Science and Engineering (Cyber Security)",
    "Rebuilt and modified by K. Likith Sai Vishal and P. Samuel",
  ];
  inst.forEach((l, i) => doc.text(l, M, 230 + i * 6));
  if (opts.studentName || opts.regNo) {
    doc.setFillColor(23, 40, 85);
    doc.roundedRect(M, 130, W - 2 * M, 38, 3, 3, "F");
    doc.setTextColor(...GOLD);
    doc.setFontSize(9);
    doc.text("STUDENT DETAILS", M + 8, 140);
    doc.setTextColor(255, 255, 255);
    doc.setFontSize(12);
    doc.text(`Name: ${opts.studentName || "—"}`, M + 8, 150);
    doc.text(`Registration No.: ${opts.regNo || "—"}`, M + 8, 158);
    doc.setFontSize(9);
    doc.setTextColor(200, 210, 230);
    doc.text(`Molecules analysed: ${opts.molecules.length}   ·   Generated: ${date}`, M + 8, 165);
  } else {
    doc.setFontSize(10);
    doc.text(`Generated: ${date}`, M, 140);
  }

  // ---- Molecules
  for (let i = 0; i < opts.molecules.length; i++) {
    const { name, smiles } = opts.molecules[i]!;
    const info = analyze(smiles);
    if (!info) continue;
    onProgress?.(`Rendering ${name} (${i + 1}/${opts.molecules.length})…`);
    const title = `${i + 1}. ${name}`;
    newPage(title);
    doc.setFont("helvetica", "bold");
    doc.setFontSize(18);
    doc.setTextColor(...INK);
    doc.text(title, M, y);
    y += 7;
    doc.setFont("courier", "normal");
    doc.setFontSize(8.5);
    doc.setTextColor(...GREY);
    doc.text(doc.splitTextToSize(`SMILES: ${info.input}`, W - 2 * M), M, y);
    y += 4.5;
    doc.text(doc.splitTextToSize(`Canonical: ${info.canonical}`, W - 2 * M), M, y);
    y += 4.5;
    doc.setFont("helvetica", "bold");
    doc.setFontSize(10);
    doc.setTextColor(...ROYAL);
    doc.text(`Formula: ${info.formula}    MW: ${info.mw.toFixed(2)} g/mol`, M, y);
    y += 5;

    const svg = drawSvg(smiles, 480, 360);
    const img2d = svg ? await svgToPng(svg) : null;
    const img3d = await render3DPng(smiles);
    const iw = (W - 2 * M - 6) / 2;
    const ih = iw * 0.75;
    doc.setDrawColor(220, 225, 235);
    if (img2d) doc.addImage(img2d, "PNG", M, y, iw, ih);
    doc.rect(M, y, iw, ih);
    if (img3d) doc.addImage(img3d, "PNG", M + iw + 6, y, iw, ih);
    doc.rect(M + iw + 6, y, iw, ih);
    doc.setFontSize(8);
    doc.setTextColor(...GREY);
    doc.setFont("helvetica", "normal");
    doc.text("2D structure", M + iw / 2, y + ih + 4, { align: "center" });
    doc.text(img3d ? "3D model (ball & stick)" : "3D model unavailable", M + iw + 6 + iw / 2, y + ih + 4, { align: "center" });
    y += ih + 10;

    // property table
    h2("Molecular properties");
    const c1 = 46;
    const c2 = 24;
    const c3 = W - 2 * M - c1 - c2;
    doc.setFillColor(...ROYAL);
    doc.rect(M, y - 4, W - 2 * M, 6.5, "F");
    doc.setFont("helvetica", "bold");
    doc.setFontSize(8.5);
    doc.setTextColor(255, 255, 255);
    doc.text("Property", M + 2, y);
    doc.text("Value", M + c1 + 2, y);
    doc.text("Interpretation", M + c1 + c2 + 2, y);
    y += 5;
    propertyRows(info).forEach((r, idx) => {
      doc.setFont("helvetica", "normal");
      doc.setFontSize(8);
      const lines = doc.splitTextToSize(r.interpretation, c3 - 4);
      const rh = Math.max(5.5, lines.length * 3.6 + 2);
      ensure(rh, title);
      if (idx % 2 === 0) {
        doc.setFillColor(242, 245, 251);
        doc.rect(M, y - 3.8, W - 2 * M, rh, "F");
      }
      doc.setTextColor(...INK);
      doc.setFont("helvetica", "bold");
      doc.text(r.label, M + 2, y);
      doc.setFont("helvetica", "normal");
      doc.text(r.value, M + c1 + 2, y);
      doc.setTextColor(...GREY);
      doc.text(lines, M + c1 + c2 + 2, y);
      y += rh;
    });
    y += 4;

    const lip = lipinski(info);
    ensure(14, title);
    h2("Lipinski Rule of Five");
    para(lip.rules.map((r) => `${r.label}: ${Number.isInteger(r.value) ? r.value : r.value.toFixed(2)} (${r.limit}) — ${r.pass ? "PASS" : "FAIL"}`).join("   |   "), 8.5, INK, title);
    y += 3;

    ensure(20, title);
    h2("Key interpretation");
    for (const [k, v] of keyPoints(name, info)) {
      ensure(10, title);
      doc.setFont("helvetica", "bold");
      doc.setFontSize(9);
      doc.setTextColor(...ROYAL);
      doc.text(`• ${k}`, M, y);
      y += 4.2;
      para(v, 8.8, INK, title);
      y += 1.5;
    }
  }

  // ---- Appendix
  if (opts.includeAppendix !== false) {
    newPage("Appendix");
    h2("Libraries & Tools Used");
    const tools = [
      ["RDKit.js (WASM)", "SMILES parsing, canonical SMILES, 2D drawing, descriptors"],
      ["3Dmol.js", "Interactive 3D molecular visualisation"],
      ["PubChem PUG-REST", "3D conformer coordinates (SDF)"],
      ["jsPDF", "PDF report generation"],
      ["Recharts", "Comparison charts"],
      ["React + TypeScript", "User interface"],
    ];
    tools.forEach(([a, b], idx) => {
      if (idx % 2 === 0) {
        doc.setFillColor(242, 245, 251);
        doc.rect(M, y - 4, W - 2 * M, 6.5, "F");
      }
      doc.setFont("helvetica", "bold");
      doc.setFontSize(9);
      doc.setTextColor(...INK);
      doc.text(a ?? "", M + 2, y);
      doc.setFont("helvetica", "normal");
      doc.setTextColor(...GREY);
      doc.text(b ?? "", M + 58, y);
      y += 6.5;
    });
    y += 6;
    h2("Example: Python RDKit workflow");
    const code = [
      "from rdkit import Chem",
      "from rdkit.Chem import Descriptors, Crippen, rdMolDescriptors, Draw, AllChem",
      "",
      'mol = Chem.MolFromSmiles("CC(=O)Oc1ccccc1C(=O)O")   # aspirin',
      "print(rdMolDescriptors.CalcMolFormula(mol))",
      "print(Descriptors.MolWt(mol), Crippen.MolLogP(mol))",
      "print(rdMolDescriptors.CalcTPSA(mol))",
      'Draw.MolToFile(mol, "aspirin_2d.png")               # 2D image',
      "molH = Chem.AddHs(mol)",
      "AllChem.EmbedMolecule(molH); AllChem.MMFFOptimizeMolecule(molH)",
      'Chem.MolToMolFile(molH, "aspirin_3d.mol")          # 3D coordinates',
    ];
    doc.setFillColor(...INK);
    doc.roundedRect(M, y - 4, W - 2 * M, code.length * 4.6 + 6, 2, 2, "F");
    doc.setFont("courier", "normal");
    doc.setFontSize(8.5);
    doc.setTextColor(200, 230, 245);
    code.forEach((l) => {
      doc.text(l, M + 4, y + 1);
      y += 4.6;
    });
    y += 12;
    h2("Limitations");
    para(
      "All descriptors in this report are computationally calculated estimates (e.g. Crippen LogP, topological PSA) and may differ from experimental values. 3D models are single conformers and do not represent the full conformational ensemble. Results are intended for educational use.",
    );
  }

  footer();
  return doc;
}
