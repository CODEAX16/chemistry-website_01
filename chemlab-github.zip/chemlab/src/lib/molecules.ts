export type Category = "Everyday" | "Drugs" | "Natural products" | "Biomolecules";

export interface ExampleMolecule {
  name: string;
  smiles: string;
  category: Category;
  fact: string;
}

export const CATEGORIES: Category[] = ["Everyday", "Drugs", "Natural products", "Biomolecules"];

export const EXAMPLES: ExampleMolecule[] = [
  { name: "Ethanol", smiles: "CCO", category: "Everyday", fact: "The alcohol in drinks and hand sanitisers — just two carbons and an OH group." },
  { name: "Benzene", smiles: "c1ccccc1", category: "Everyday", fact: "Kekulé reportedly dreamt of a snake biting its tail before proposing its ring." },
  { name: "Phenol", smiles: "Oc1ccccc1", category: "Everyday", fact: "Lister used phenol (carbolic acid) as one of the first surgical antiseptics." },
  { name: "Acetic Acid", smiles: "CC(=O)O", category: "Everyday", fact: "Gives vinegar its sharp smell — vinegar is about 5% acetic acid." },
  { name: "Aspirin", smiles: "CC(=O)Oc1ccccc1C(=O)O", category: "Drugs", fact: "Derived from salicin in willow bark, used as a remedy for thousands of years." },
  { name: "Caffeine", smiles: "CN1C=NC2=C1C(=O)N(C(=O)N2C)C", category: "Natural products", fact: "Blocks adenosine receptors in the brain — that's why coffee keeps you awake." },
  { name: "Paracetamol", smiles: "CC(=O)Nc1ccc(O)cc1", category: "Drugs", fact: "One of the most widely used pain relievers and fever reducers in the world." },
  { name: "Ibuprofen", smiles: "CC(C)Cc1ccc(cc1)C(C)C(=O)O", category: "Drugs", fact: "Has one chiral centre; only the (S)-form is pharmacologically active." },
  { name: "Nicotine", smiles: "CN1CCCC1c1cccnc1", category: "Natural products", fact: "Tobacco plants make nicotine as a natural insecticide." },
  { name: "Glucose", smiles: "OC[C@H]1OC(O)[C@H](O)[C@@H](O)[C@@H]1O", category: "Biomolecules", fact: "Your brain uses roughly 120 g of glucose every single day." },
  { name: "Vanillin", smiles: "COc1cc(C=O)ccc1O", category: "Natural products", fact: "The main flavour molecule of vanilla — most is now made synthetically." },
  { name: "Dopamine", smiles: "NCCc1ccc(O)c(O)c1", category: "Biomolecules", fact: "A neurotransmitter linked to reward, motivation and movement." },
  { name: "Menthol", smiles: "CC(C)C1CCC(C)CC1O", category: "Natural products", fact: "Triggers cold-sensing TRPM8 receptors, so it feels cool without lowering temperature." },
  { name: "Capsaicin", smiles: "COC1=C(C=CC(=C1)CNC(=O)CCCCC=CC(C)C)O", category: "Natural products", fact: "The heat in chilli peppers — it activates the same receptor as real heat." },
];

export const DEFAULT_SMILES = "CN1C=NC2=C1C(=O)N(C(=O)N2C)C";

export function findExample(smiles: string) {
  return EXAMPLES.find((e) => e.smiles === smiles);
}

export function moleculeOfTheDay(date = new Date()) {
  const day = Math.floor(date.getTime() / 86400000);
  return EXAMPLES[day % EXAMPLES.length]!;
}
