import { useEffect, useState } from "react";
import { Check, X, FlaskConical } from "lucide-react";
import { useMol } from "@/lib/molstate";
import { isValidSmiles } from "@/lib/rdkit";
import { EXAMPLES, findExample } from "@/lib/molecules";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { cn } from "@/lib/utils";

/** Shared SMILES input bound to global molecule state. */
export function SmilesInput() {
  const { smiles, setSmiles, ready } = useMol();
  const [draft, setDraft] = useState(smiles);
  useEffect(() => setDraft(smiles), [smiles]);

  const valid = ready && draft.trim() ? isValidSmiles(draft) : null;

  useEffect(() => {
    if (valid && draft.trim() !== smiles) {
      const t = setTimeout(() => setSmiles(draft.trim()), 350);
      return () => clearTimeout(t);
    }
    return undefined;
  }, [draft, valid, smiles, setSmiles]);

  const ex = findExample(smiles);

  return (
    <div className="glass gradient-border rounded-2xl p-4 sm:p-5">
      <div className="flex flex-col gap-3 md:flex-row md:items-end">
        <div className="flex-1">
          <label htmlFor="smiles" className="mb-1.5 block text-xs font-semibold uppercase tracking-wider text-muted-foreground">
            SMILES string
          </label>
          <div className="relative">
            <Input
              id="smiles"
              value={draft}
              onChange={(e) => setDraft(e.target.value)}
              spellCheck={false}
              autoComplete="off"
              aria-invalid={valid === false}
              aria-describedby="smiles-status"
              className={cn(
                "h-12 pr-11 font-mono text-base",
                valid === true && "border-success/60 focus-visible:ring-success/40",
                valid === false && "border-destructive/70 focus-visible:ring-destructive/40",
              )}
              placeholder="e.g. CCO"
            />
            <span className="absolute right-3 top-1/2 -translate-y-1/2">
              {valid === true && <Check className="h-5 w-5 text-success" aria-hidden />}
              {valid === false && <X className="h-5 w-5 text-destructive" aria-hidden />}
            </span>
          </div>
        </div>
        <div className="md:w-64">
          <label className="mb-1.5 block text-xs font-semibold uppercase tracking-wider text-muted-foreground">Example molecule</label>
          <Select value={ex?.smiles ?? ""} onValueChange={(v) => setSmiles(v)}>
            <SelectTrigger className="h-12" aria-label="Choose an example molecule">
              <FlaskConical className="h-4 w-4 text-cyan" />
              <SelectValue placeholder="Choose an example" />
            </SelectTrigger>
            <SelectContent>
              {EXAMPLES.map((e) => (
                <SelectItem key={e.smiles} value={e.smiles}>
                  {e.name}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
      </div>
      <p id="smiles-status" className="mt-2 min-h-5 text-sm" aria-live="polite">
        {!ready && <span className="text-muted-foreground">Loading chemistry engine…</span>}
        {valid === true && <span className="text-success">Valid SMILES — structure parsed successfully.</span>}
        {valid === false && (
          <span className="text-destructive">
            Hmm, that SMILES can't be parsed. Check ring digits are paired, brackets are closed and atom symbols are valid.
          </span>
        )}
      </p>
    </div>
  );
}
