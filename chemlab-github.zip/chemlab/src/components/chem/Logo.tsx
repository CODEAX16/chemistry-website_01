export function LogoMark({ className = "h-8 w-8" }: { className?: string }) {
  return (
    <svg viewBox="0 0 40 40" className={className} aria-hidden="true">
      <defs>
        <linearGradient id="lg-hex" x1="0" y1="0" x2="1" y2="1">
          <stop offset="0" stopColor="var(--cyan)" />
          <stop offset="1" stopColor="var(--primary)" />
        </linearGradient>
      </defs>
      <polygon points="20,3 34.7,11.5 34.7,28.5 20,37 5.3,28.5 5.3,11.5" fill="none" stroke="url(#lg-hex)" strokeWidth="2.4" strokeLinejoin="round" />
      <circle cx="20" cy="20" r="6" fill="none" stroke="var(--cyan)" strokeWidth="1.6" opacity="0.8" />
      <line x1="20" y1="3" x2="20" y2="10" stroke="var(--gold)" strokeWidth="2" />
      <circle cx="20" cy="3.5" r="2.6" fill="var(--gold)" />
      <circle cx="34.7" cy="28.5" r="2.2" fill="var(--cyan)" />
      <circle cx="5.3" cy="28.5" r="2.2" fill="var(--primary)" />
    </svg>
  );
}

export function Wordmark() {
  return (
    <span className="flex items-center gap-2">
      <LogoMark />
      <span className="font-display text-lg font-bold tracking-tight">
        Chem<span className="text-gradient">Lab</span>
      </span>
    </span>
  );
}
