/* eslint-disable @typescript-eslint/no-explicit-any */
import { forwardRef, useEffect, useImperativeHandle, useRef, useState } from "react";
import { get3D, type Source3D } from "@/lib/structure3d";
import { useMol } from "@/lib/molstate";
import { Loader2 } from "lucide-react";
import { cn } from "@/lib/utils";

export type Style3D = "ballstick" | "stick" | "sphere" | "line";

export const STYLE_LABELS: Record<Style3D, string> = {
  ballstick: "Ball & Stick",
  stick: "Stick",
  sphere: "Space Filling",
  line: "Wireframe",
};

export function styleSpec(s: Style3D) {
  const cs = "Jmol";
  switch (s) {
    case "ballstick":
      return { stick: { radius: 0.14, colorscheme: cs }, sphere: { scale: 0.28, colorscheme: cs } };
    case "stick":
      return { stick: { radius: 0.22, colorscheme: cs } };
    case "sphere":
      return { sphere: { scale: 1.0, colorscheme: cs } };
    case "line":
      return { line: { linewidth: 2, colorscheme: cs } };
  }
}

export interface Viewer3DHandle {
  reset: () => void;
  png: () => string | null;
}

interface Props {
  smiles: string;
  style?: Style3D;
  surface?: boolean;
  spin?: boolean;
  labels?: boolean;
  background?: string; // hex or "transparent"
  className?: string;
  interactive?: boolean;
  onSource?: (s: Source3D | null) => void;
}

export const Viewer3D = forwardRef<Viewer3DHandle, Props>(function Viewer3D(
  { smiles, style = "ballstick", surface = false, spin = false, labels = false, background = "transparent", className, interactive = true, onSource },
  ref,
) {
  const { ready } = useMol();
  const host = useRef<HTMLDivElement>(null);
  const viewer = useRef<any>(null);
  const lib = useRef<any>(null);
  const [state, setState] = useState<"loading" | "ok" | "error">("loading");
  const [model, setModel] = useState(0);

  useImperativeHandle(ref, () => ({
    reset: () => {
      viewer.current?.zoomTo();
      viewer.current?.render();
    },
    png: () => viewer.current?.pngURI?.() ?? null,
  }));

  // create viewer + load molecule
  useEffect(() => {
    if (!ready || !host.current) return;
    let cancelled = false;
    setState("loading");
    (async () => {
      const mod: any = await import("3dmol");
      const $3D = mod.default?.createViewer ? mod.default : mod;
      lib.current = $3D;
      const res = await get3D(smiles);
      if (cancelled || !host.current) return;
      onSource?.(res?.source ?? null);
      if (!res) {
        setState("error");
        return;
      }
      if (!viewer.current) {
        viewer.current = $3D.createViewer(host.current, {
          backgroundColor: "white",
          backgroundAlpha: 0,
          antialias: true,
          disableFog: true,
        });
        if (!interactive) host.current.style.pointerEvents = "none";
      }
      const v = viewer.current;
      v.clear();
      v.addModel(res.data, "sdf");
      setState("ok");
      setModel((m) => m + 1);
    })().catch(() => !cancelled && setState("error"));
    return () => {
      cancelled = true;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [ready, smiles]);

  // apply visual options
  useEffect(() => {
    const v = viewer.current;
    const $3D = lib.current;
    if (!v || !$3D || state !== "ok") return;
    v.setStyle({}, styleSpec(style));
    v.removeAllSurfaces();
    if (surface) v.addSurface($3D.SurfaceType?.VDW ?? 1, { opacity: 0.55, colorscheme: "Jmol" });
    v.removeAllLabels();
    if (labels) {
      v.addPropertyLabels("elem", { not: { elem: "H" } }, {
        fontColor: "black",
        backgroundColor: "white",
        backgroundOpacity: 0.75,
        fontSize: 11,
        showBackground: true,
        inFront: true,
        alignment: "center",
      });
    }
    if (background === "transparent") v.setBackgroundColor("white", 0);
    else v.setBackgroundColor(background, 1);
    v.zoomTo();
    v.spin(spin ? "y" : false);
    if (spin) v.spin("y", 0.6);
    v.render();
  }, [style, surface, labels, background, spin, state, model]);

  useEffect(() => {
    const onResize = () => viewer.current?.resize();
    window.addEventListener("resize", onResize);
    return () => {
      window.removeEventListener("resize", onResize);
      try {
        viewer.current?.spin(false);
        viewer.current?.clear();
      } catch {
        /* noop */
      }
      viewer.current = null;
    };
  }, []);

  return (
    <div className={cn("relative h-full w-full", className)} aria-label="Interactive 3D molecule viewer">
      <div ref={host} className="absolute inset-0" />
      {state === "loading" && (
        <div className="absolute inset-0 flex items-center justify-center gap-2 text-sm text-muted-foreground">
          <Loader2 className="h-4 w-4 animate-spin" /> Building 3D model…
        </div>
      )}
      {state === "error" && (
        <div className="absolute inset-0 flex items-center justify-center p-6 text-center text-sm text-muted-foreground">
          3D coordinates could not be generated for this molecule.
        </div>
      )}
    </div>
  );
});
