import { motion } from "framer-motion";

interface Zone {
  to: number;
  label: string;
  className: string;
}

/** Horizontal gauge with coloured zones and an animated marker. */
export function Gauge({ value, min, max, zones, unit = "" }: { value: number; min: number; max: number; zones: Zone[]; unit?: string }) {
  const pct = Math.max(0, Math.min(1, (value - min) / (max - min))) * 100;
  let start = min;
  return (
    <div>
      <div className="relative flex h-3 overflow-hidden rounded-full">
        {zones.map((z) => {
          const w = ((Math.min(z.to, max) - start) / (max - min)) * 100;
          start = z.to;
          return <div key={z.label} className={z.className} style={{ width: `${w}%` }} />;
        })}
      </div>
      <div className="relative h-6">
        <motion.div
          className="absolute -top-5 flex -translate-x-1/2 flex-col items-center"
          initial={{ left: "0%" }}
          animate={{ left: `${pct}%` }}
          transition={{ duration: 1.1, ease: "easeOut" }}
        >
          <div className="h-7 w-1 rounded-full bg-foreground shadow" />
        </motion.div>
      </div>
      <div className="flex justify-between text-[11px] text-muted-foreground">
        {zones.map((z) => (
          <span key={z.label}>{z.label}</span>
        ))}
      </div>
      <p className="sr-only">
        Value {value.toFixed(2)}
        {unit}
      </p>
    </div>
  );
}
