import { useMemo } from "react";
import { useMol } from "@/lib/molstate";
import { drawSvg } from "@/lib/rdkit";
import { Skeleton } from "@/components/ui/skeleton";
import { cn } from "@/lib/utils";

interface Props {
  smiles: string;
  width?: number;
  height?: number;
  className?: string;
  label?: string;
}

/** 2D structure rendered by RDKit.js on a white "paper" tile (CPK atom colours). */
export function MolSvg({ smiles, width = 320, height = 240, className, label }: Props) {
  const { ready } = useMol();
  const svg = useMemo(() => (ready ? drawSvg(smiles, width, height) : null), [ready, smiles, width, height]);
  if (!ready) return <Skeleton className={cn("aspect-[4/3] w-full rounded-xl", className)} />;
  if (!svg)
    return (
      <div className={cn("flex aspect-[4/3] w-full items-center justify-center rounded-xl border border-dashed text-sm text-muted-foreground", className)}>
        No structure
      </div>
    );
  return (
    <div
      role="img"
      aria-label={label ?? `2D structure of ${smiles}`}
      className={cn("w-full overflow-hidden rounded-xl bg-paper [&>svg]:h-full [&>svg]:w-full", className)}
      style={{ aspectRatio: `${width}/${height}` }}
      dangerouslySetInnerHTML={{ __html: svg }}
    />
  );
}
