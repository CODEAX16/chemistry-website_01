import { Link, useNavigate } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { Menu, Moon, Search, Sun, Atom } from "lucide-react";
import { Wordmark } from "./Logo";
import { Button } from "@/components/ui/button";
import { Sheet, SheetContent, SheetTitle, SheetTrigger } from "@/components/ui/sheet";
import { CommandDialog, CommandEmpty, CommandGroup, CommandInput, CommandItem, CommandList } from "@/components/ui/command";
import { EXAMPLES } from "@/lib/molecules";
import { useMol } from "@/lib/molstate";

export const NAV = [
  { to: "/", label: "Home" },
  { to: "/theory", label: "Theory" },
  { to: "/lab", label: "Visualization Lab" },
  { to: "/properties", label: "Properties" },
  { to: "/analysis", label: "Structure–Property" },
  { to: "/quiz", label: "Assessment" },
  { to: "/report", label: "Final Report" },
] as const;

function useTheme() {
  const [dark, setDark] = useState(true);
  useEffect(() => {
    setDark(localStorage.getItem("chemlab.theme") !== "light");
  }, []);
  useEffect(() => {
    document.documentElement.classList.toggle("dark", dark);
  }, [dark]);
  const toggle = () => {
    setDark((d) => {
      localStorage.setItem("chemlab.theme", d ? "light" : "dark");
      return !d;
    });
  };
  return { dark, toggle };
}

export function Navbar() {
  const { dark, toggle } = useTheme();
  const [open, setOpen] = useState(false);
  const [cmd, setCmd] = useState(false);

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === "k") {
        e.preventDefault();
        setCmd((c) => !c);
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, []);

  return (
    <header className="sticky top-0 z-50 border-b border-border/60 bg-background/70 backdrop-blur-xl">
      <div className="mx-auto flex h-16 max-w-7xl items-center gap-4 px-4 sm:px-6">
        <Link to="/" aria-label="ChemLab home" className="shrink-0">
          <Wordmark />
        </Link>
        <nav className="ml-4 hidden items-center gap-1 xl:flex" aria-label="Main">
          {NAV.map((n) => (
            <Link
              key={n.to}
              to={n.to}
              activeOptions={{ exact: n.to === "/" }}
              className="rounded-lg px-3 py-2 text-sm font-medium text-muted-foreground transition-colors hover:bg-accent/50 hover:text-foreground data-[status=active]:bg-primary/15 data-[status=active]:text-foreground"
            >
              {n.label}
            </Link>
          ))}
        </nav>
        <div className="ml-auto flex items-center gap-2">
          <Button variant="outline" size="sm" onClick={() => setCmd(true)} className="hidden gap-2 bg-card/50 text-muted-foreground sm:flex" aria-label="Open search">
            <Search className="h-4 w-4" /> Search
            <kbd className="rounded border border-border px-1.5 font-mono text-[10px]">Ctrl K</kbd>
          </Button>
          <Button variant="ghost" size="icon" onClick={() => setCmd(true)} className="sm:hidden" aria-label="Open search">
            <Search className="h-5 w-5" />
          </Button>
          <Button variant="ghost" size="icon" onClick={toggle} aria-label={dark ? "Switch to light mode" : "Switch to dark mode"}>
            {dark ? <Sun className="h-5 w-5" /> : <Moon className="h-5 w-5" />}
          </Button>
          <Sheet open={open} onOpenChange={setOpen}>
            <SheetTrigger asChild>
              <Button variant="ghost" size="icon" className="xl:hidden" aria-label="Open menu">
                <Menu className="h-5 w-5" />
              </Button>
            </SheetTrigger>
            <SheetContent side="right" className="w-72">
              <SheetTitle className="px-2 pt-2">
                <Wordmark />
              </SheetTitle>
              <nav className="mt-6 flex flex-col gap-1 px-2" aria-label="Mobile">
                {NAV.map((n) => (
                  <Link
                    key={n.to}
                    to={n.to}
                    onClick={() => setOpen(false)}
                    activeOptions={{ exact: n.to === "/" }}
                    className="rounded-lg px-3 py-2.5 text-sm font-medium text-muted-foreground hover:bg-accent/50 data-[status=active]:bg-primary/15 data-[status=active]:text-foreground"
                  >
                    {n.label}
                  </Link>
                ))}
              </nav>
            </SheetContent>
          </Sheet>
        </div>
      </div>
      <CommandPalette open={cmd} setOpen={setCmd} />
    </header>
  );
}

function CommandPalette({ open, setOpen }: { open: boolean; setOpen: (o: boolean) => void }) {
  const navigate = useNavigate();
  const { setSmiles } = useMol();
  return (
    <CommandDialog open={open} onOpenChange={setOpen}>
      <CommandInput placeholder="Jump to a page or molecule…" />
      <CommandList>
        <CommandEmpty>No results found.</CommandEmpty>
        <CommandGroup heading="Pages">
          {NAV.map((n) => (
            <CommandItem
              key={n.to}
              onSelect={() => {
                navigate({ to: n.to });
                setOpen(false);
              }}
            >
              {n.label}
            </CommandItem>
          ))}
        </CommandGroup>
        <CommandGroup heading="Molecules (opens in the lab)">
          {EXAMPLES.map((e) => (
            <CommandItem
              key={e.smiles}
              value={`${e.name} ${e.smiles}`}
              onSelect={() => {
                setSmiles(e.smiles);
                navigate({ to: "/lab" });
                setOpen(false);
              }}
            >
              <Atom className="h-4 w-4 text-cyan" />
              {e.name}
              <span className="ml-auto truncate font-mono text-xs text-muted-foreground">{e.smiles}</span>
            </CommandItem>
          ))}
        </CommandGroup>
      </CommandList>
    </CommandDialog>
  );
}

export function Footer() {
  return (
    <footer className="mt-24 border-t border-border/60 bg-background/60">
      <div className="mx-auto grid max-w-7xl gap-8 px-4 py-12 sm:px-6 md:grid-cols-3">
        <div>
          <Wordmark />
          <p className="mt-3 text-sm text-muted-foreground">Cheminformatics Virtual Laboratory for representing, visualizing and analysing chemical structures.</p>
        </div>
        <div className="text-sm text-muted-foreground">
          <p className="font-semibold text-foreground">SRM Institute of Science and Technology, Tiruchirappalli</p>
          <p>Department of Computer Science and Engineering (Cyber Security)</p>
          <p className="mt-2">
            Rebuilt and modified by <span className="font-medium text-gold">K. Likith Sai Vishal and P. Samuel</span>
          </p>
        </div>
        <div className="flex flex-col gap-1.5 text-sm">
          {NAV.slice(1).map((n) => (
            <Link key={n.to} to={n.to} className="text-muted-foreground hover:text-foreground">
              {n.label}
            </Link>
          ))}
        </div>
      </div>
      <div className="border-t border-border/60 px-4 py-5 text-center text-xs text-muted-foreground">
        <p>Cheminformatics Virtual Laboratory · SRM Institute of Science and Technology, Tiruchirappalli · Department of Computer Science and Engineering (Cyber Security) · Rebuilt and modified by K. Likith Sai Vishal and P. Samuel</p>
        <p className="mt-1 text-gold/90">Descriptors are computationally calculated estimates.</p>
      </div>
    </footer>
  );
}
