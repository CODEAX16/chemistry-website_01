export const CPK: { el: string; name: string; color: string }[] = [
  { el: "C", name: "Carbon", color: "#909090" },
  { el: "H", name: "Hydrogen", color: "#FFFFFF" },
  { el: "O", name: "Oxygen", color: "#FF0D0D" },
  { el: "N", name: "Nitrogen", color: "#3050F8" },
  { el: "S", name: "Sulfur", color: "#FFFF30" },
  { el: "Cl", name: "Chlorine", color: "#1FF01F" },
  { el: "F", name: "Fluorine", color: "#90E050" },
  { el: "P", name: "Phosphorus", color: "#FF8000" },
  { el: "Br", name: "Bromine", color: "#A62929" },
];

export function AtomLegend() {
  return (
    <ul className="flex flex-wrap gap-2" aria-label="Atom colour legend (CPK)">
      {CPK.map((a) => (
        <li key={a.el} className="flex items-center gap-1.5 rounded-full border border-border bg-card px-2.5 py-1 text-xs">
          {/* CPK colours are data, intentionally fixed */}
          <span className="h-3 w-3 rounded-full ring-1 ring-border" style={{ background: a.color }} aria-hidden />
          <span className="font-semibold">{a.el}</span>
          <span className="text-muted-foreground">{a.name}</span>
        </li>
      ))}
    </ul>
  );
}
